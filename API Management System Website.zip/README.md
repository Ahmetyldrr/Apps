
  # API Management System Website

  This is a code bundle for API Management System Website. The original project is available at https://www.figma.com/design/TqhUeXyFcz6gqZItfi2dTY/API-Management-System-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  